# Manuscript figure reference

Working materials for writing the EFF-Dock manuscript, not a published paper.

- [Combined PDF](paper_figures.pdf)
- [English captions and author notes](FIGURE_CAPTIONS.md)
- `methods.tex`: editable equations and current methods.
- `main.tex` and `figure_captions.tex`: reference LaTeX document and figure blocks.
- `figures/`: 20 individual PDFs in manuscript page order.
- `captions.json`: file, caption, label and checksum mapping. The
  `repository_numerical_inputs` entries refer to the GitHub source checkout.

Use XeLaTeX or LuaLaTeX for the reference document. Adapt numbering, placement
and citation keys to the manuscript. Methods are working manuscript text;
the repository methods and parameter tables provide implementation detail.
