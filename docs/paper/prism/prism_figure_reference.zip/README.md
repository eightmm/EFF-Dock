# Manuscript figure reference

Working materials for writing the EFF-Dock manuscript, not a published paper.

- [Combined PDF](paper_figures.pdf)
- [English captions and author notes](FIGURE_CAPTIONS.md)
- `main.tex` and `figure_captions.tex`: reference LaTeX document and figure blocks.
- `figures/`: 14 individual PDFs in manuscript page order.
- `captions.json`: file, caption, label and checksum mapping.

Use XeLaTeX or LuaLaTeX for the reference document. Adapt numbering, placement
and citation keys to the manuscript. Local TeX compilation is unverified.
